package employedata;

import java.util.Map;
import java.util.TreeMap;

import bean.Employee;

public class Employedata {
	public Map<String,Employee> map;
	public Employedata() {
		map = new TreeMap<String,Employee>();
	}
}
